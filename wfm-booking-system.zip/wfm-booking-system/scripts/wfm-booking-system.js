function showError(fieldId, message) {
    const errorElement = document.getElementById(fieldId + '_error');
    if (errorElement) {
        errorElement.textContent = message;
    }
}

function clearErrors() {
    const errorElements = document.querySelectorAll('.error-message');
    errorElements.forEach(element => element.textContent = '');
}

function validateForm() {
    clearErrors();

    const parentName = document.getElementById('parent_name').value.trim();
    const parentEmail = document.getElementById('parent_email').value.trim();
    const parentPhone = document.getElementById('parent_phone').value.trim();
    const childName = document.getElementById('child_name').value.trim();

    const namePattern = /^[А-ЯЁ][а-яё]+\s[А-ЯЁ][а-яё]+\s[А-ЯЁ][а-яё]+$/;
    const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    const phonePattern = /^\+7 \(\d{3}\) \d{3}-\d{2}-\d{2}$/;

    let isValid = true;

    if (!namePattern.test(parentName)) {
        showError('parent_name', 'Введите ФИО в формате: Фамилия Имя Отчество');
        isValid = false;
    }

    if (!emailPattern.test(parentEmail)) {
        showError('parent_email', 'Введите корректный адрес электронной почты.');
        isValid = false;
    }

    if (!phonePattern.test(parentPhone)) {
        showError('parent_phone', 'Введите телефон в формате +7 (XXX) XXX-XX-XX');
        isValid = false;
    }

    if (!namePattern.test(childName)) {
        showError('child_name', 'Введите ФИО в формате: Фамилия Имя Отчество');
        isValid = false;
    }

    return isValid; // Возвращаем результат валидации
}

jQuery(document).ready(function($) {


    function allowOnlyCyrillic(inputField) {
        inputField.addEventListener('input', function(event) {
            const value = event.target.value;
            // Регулярное выражение: разрешаем только кириллицу, пробелы и дефисы
            const cyrillicPattern = /^[А-Яа-яЁё\s-]*$/;
            if (!cyrillicPattern.test(value)) {
                // Удаляем последний введённый символ, если он не соответствует шаблону
                event.target.value = value.replace(/[^А-Яа-яЁё\s-]/g, '');
            }
        });
    }

    // Применяем ограничение к полям ФИО
    allowOnlyCyrillic(document.getElementById('parent_name'));
    allowOnlyCyrillic(document.getElementById('child_name'));


    $('#parent_phone').inputmask({
        mask: '+7 (999) 999-99-99',
        placeholder: '_',
        clearIncomplete: true
    });

    let formSubmitted = false; // Переменная для отслеживания отправки формы

    $('#booking-form').on('submit', function(e) {
        e.preventDefault(); // Отменяем стандартное поведение формы

        // Проверяем, была ли форма уже отправлена
        if (formSubmitted) {
            return; // Если да, выходим из функции
        }

        // Проверяем форму
        if (!validateForm()) {
            return false; // Если валидация не прошла, останавливаем выполнение
        }

        formSubmitted = true; // Устанавливаем флаг, что форма отправлена

        var formData = $(this).serialize() + '&action=send_confirmation_code';

        $.ajax({
            url: ajax_object.ajaxurl, // URL для AJAX-запросов
            type: 'POST',
            data: formData,
            success: function(response) {
                if (response.success) {
                    // Показываем раздел с кодом подтверждения
                    $('#confirmation-code-section').show();
                    $('#booking-form').hide();
                    $('#booking_id').val(response.data.id); // Сохраняем booking_id
                    $('#verification_response').html('<p>Код подтверждения отправлен на вашу почту.</p>');
                } else {
                    // Показываем ошибку, если что-то пошло не так
                    $('#verification_response').html('<p>Ошибка: ' + response.data + '</p>');
                }
            },
            error: function() {
                showError('general_error', 'Произошла ошибка при отправке формы бронирования.');
            },
            complete: function() {
                formSubmitted = false; // Сбрасываем флаг после завершения запроса
            }
        });
    });

    // Обработка проверки кода подтверждения
    $('#verify_code_button').on('click', function() {
        var confirmation_code = $('#confirmation_code_input').val();
        var booking_id = $('#booking_id').val(); // Получаем booking_id из скрытого поля

        $.ajax({
            url: ajax_object.ajaxurl, // URL для AJAX-запросов
            type: 'POST',
            data: {
                action: 'verify_confirmation_code',
                confirmation_code: confirmation_code,
                booking_id: booking_id
            },
            success: function(response) {
                if (response.success) {
                    // Показываем информацию о бронировании
                    $('#verification_response').html('<p>Бронирование успешно завершено!</p>');
                    $('#confirmation-code-section').hide();
                    $('#booking-details').show();

                    // Заполнение информации о брони
                    $('#booking-parent-name').text(response.data.parent_name);
                    $('#booking-parent-email').text(response.data.parent_email);
                    $('#booking-parent-phone').text(response.data.parent_phone);
                    $('#booking-child-name').text(response.data.child_name);
                    $('#booking-child-birth-date').text(response.data.child_birth_date);
                    $('#booking-shift').text(response.data.shift);
                } else {
                    // Показываем ошибку, если код подтверждения неверный
                    $('#verification_response').html('<p>Ошибка: ' + response.data + '</p>');
                }
            },
            error: function() {
                showError('general_error', 'Произошла ошибка при проверке кода подтверждения.');
            }
        });
    });
});
