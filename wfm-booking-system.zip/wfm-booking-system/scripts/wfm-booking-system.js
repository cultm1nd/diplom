function validateForm() {
    const parentName = document.getElementById('parent_name').value.trim();
    const parentEmail = document.getElementById('parent_email').value.trim();
    const parentPhone = document.getElementById('parent_phone').value.trim();
    const childName = document.getElementById('child_name').value.trim();

    // выражения для валидации
    const namePattern = /^[А-ЯЁ][а-яё]+\s[А-ЯЁ][а-яё]+\s[А-ЯЁ][а-яё]+$/; // ФИО с пробелами


    // ФИО родителя
    if (!namePattern.test(parentName)) {
        alert("Пожалуйста, введите ФИО родителя в формате: Фамилия Имя Отчество");
        return false;
    }

    // эл почта
    if (!parentEmail) {
        alert("Пожалуйста, введите корректный адрес электронной почты.");
        return false;
    }

    if (!parentPhone) {
        alert("Пожалуйста, введите корректный телефон  в формате +7 (XXX) XXX-XX-XX");
        return false;
    }
 

    // ФИО ребенка
    if (!namePattern.test(childName)) {
        alert("Пожалуйста, введите ФИО ребенка в формате: Фамилия Имя Отчество");
        return false;
    }

    return true;
}

jQuery(document).ready(function($) {
    $('#parent_phone').inputmask({
        mask: "+7 (999) 999-99-99",
        placeholder: " ",
        showMaskOnHover: false,
        showMaskOnFocus: true,
        onBeforePaste: function (pastedValue) {
            //удаление всего, кроме цифр
            return pastedValue.replace(/\D/g, '');
        }
    });
    // обработка отправки формы бронирования
    $('#booking-form').on('submit', function(e) {
        e.preventDefault(); 

        if (validateForm()) {
            var formData = $(this).serialize() + '&action=send_confirmation_code';

            $.ajax({
                url: ajax_object.ajaxurl,
                type: 'POST',
                data: formData,
                success: function(response) {
                    if (response.success) {
                        // отображение кода подтверждения и поля для ввода
                        $('#response').html(`
                            <p>Ваш код подтверждения: ${response.data.confirmation_code}</p>
                            <input type="text" id="input_confirmation_code" placeholder="Введите код подтверждения" required>
                            <button id="verify_code">Подтвердить</button>`);
                        
                        // проверка кода подтверждения
                        $('#verify_code').on('click', function() {
                            var confirmation_code = $('#input_confirmation_code').val();
                            var booking_id = response.data.id; // сохранение ID бронирования

                            $.ajax({
                                url: ajax_object.ajaxurl,
                                type: 'POST',
                                data: {
                                    action: 'verify_confirmation_code',
                                    confirmation_code: confirmation_code,
                                    booking_id: booking_id
                                },
                                success: function(verifyResponse) {
                                    if (verifyResponse.success) {
                                        //информация о бронировании
                                        var bookingInfo = verifyResponse.data;
                                        var modalContent = `
                                            <div class="modal">
                                                <h2>Информация о бронировании</h2>
                                                <p>ФИО родителя: ${bookingInfo.parent_name}</p>
                                                <p>Электронная почта: ${bookingInfo.parent_email}</p>
                                                <p>Телефон: ${bookingInfo.parent_phone}</p>
                                                <p>ФИО ребенка: ${bookingInfo.child_name}</p>
                                                <p>Дата рождения: ${bookingInfo.child_birth_date}</p>
                                                <p>Смена: ${bookingInfo.shift}</p>
                                                <p>Билет успешно забронирован!</p>
                                                <button id="close_modal">Закрыть</button>
                                            </div>
                                        `;
                                        $('#response').html(modalContent);

                                        // закрытие модального окна
                                        $('#close_modal').on('click', function() {
                                            $('#response').empty(); 
                                        });
                                    } else {
                                        alert('Ошибка: ' + verifyResponse.data); 
                                    }
                                },
                                error: function() {
                                    alert('Произошла ошибка при проверке кода подтверждения.');
                                }
                            });
                        });
                    } else {
                        alert('Ошибка: ' + response.data); 
                    }
                },
                error: function() {
                    alert('Произошла ошибка при отправке формы бронирования.'); 
                }
            });
        }
    });
});

