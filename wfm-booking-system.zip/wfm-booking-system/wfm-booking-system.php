<?php
/*
Plugin Name: WFM Booking System
Description: Система бронирования билетов для ДОЛ "Акакуль".
Version: 1.0
Author: Polina
*/
defined('ABSPATH') or die;

// подключение файлов
include_once(plugin_dir_path(__FILE__) . 'includes/wfm-booking-functions.php');
include_once(plugin_dir_path(__FILE__) . 'includes/wfm-booking-admin.php');

// хук активации плагина
register_activation_hook(__FILE__, 'create_booking_table');
// формирование таблицы в бд
function create_booking_table() {
    global $wpdb;    
    $table_name = $wpdb->prefix . 'wfm_bookings';
    $charset_collate = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE IF NOT EXISTS $table_name (
        id mediumint(9) NOT NULL AUTO_INCREMENT,
        parent_name tinytext NOT NULL,
        parent_email varchar(100) NOT NULL,
        parent_phone varchar(255) NOT NULL,
        child_name tinytext NOT NULL,
        child_birth_date date NOT NULL,
        shift varchar(10) NOT NULL,
        confirmation_code int(6) NOT NULL,
        status varchar(20) DEFAULT 'processing',
        created_at datetime DEFAULT CURRENT_TIMESTAMP NOT NULL,
        PRIMARY KEY (id)
    ) $charset_collate;";

require_once(ABSPATH . 'wp-admin/includes/upgrade.php');

    dbDelta($sql);
}
function booking_enqueue_scripts() {
    // Подключаем библиотеку Inputmask перед основным скриптом
    wp_enqueue_script('jquery-inputmask', 'https://cdnjs.cloudflare.com/ajax/libs/jquery.inputmask/5.0.7/jquery.inputmask.min.js', array('jquery'), null, true);
    
    // Подключаем основной скрипт
    wp_enqueue_script('wfm-booking-system-js', plugin_dir_url(__FILE__) . 'scripts/wfm-booking-system.js', array('jquery', 'jquery-inputmask'), null, true);
    
    // Локализация AJAX
    wp_localize_script('wfm-booking-system-js', 'ajax_object', array('ajaxurl' => admin_url('admin-ajax.php')));
}
add_action('wp_enqueue_scripts', 'booking_enqueue_scripts');

add_action('wp_enqueue_scripts', 'booking_enqueue_scripts');//add_action закрепляет указанную функцию на хуке(функция, кот перехватывает на себя выполнение определённых функций, позволяет перехватывать данные и видоизменять их вывод)