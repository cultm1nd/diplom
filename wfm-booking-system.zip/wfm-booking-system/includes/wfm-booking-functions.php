<?php
class BookingSystem {
    public function __construct() {
        add_shortcode('wfm_booking_form', array($this, 'render_booking_form'));
        add_action('wp_ajax_nopriv_send_confirmation_code', array($this, 'send_confirmation_code'));
        add_action('wp_ajax_send_confirmation_code', array($this, 'send_confirmation_code'));
        add_action('wp_ajax_nopriv_verify_confirmation_code', array($this, 'verify_confirmation_code'));
        add_action('wp_ajax_verify_confirmation_code', array($this, 'verify_confirmation_code'));
    }

    public function render_booking_form() {
        ob_start();
        ?>
        <div class="form">
            <div class="infs">
                <form id="booking-form" method="POST" onsubmit="return validateForm()">
                    <div class="parents">
                        <h3 class="title">Данные о родителе</h3>
                        <div class="input-container ic1">
                            <input type="text" id="parent_name" class="input" name="parent_name" placeholder="" required>
                            <div class="cut"></div>
                            <label for="parent_name" class="placeholder">ФИО родителя</label>
                        </div>
                        <div class="input-container ic2">
                            <input type="email" id="parent_email" class="input" name="parent_email" placeholder="" required> 
                            <div class="cut"></div>
                            <label for="parent_email" class="placeholder">Электронная почта</label>
                        </div>
                        <div class="input-container ic3">
                            <input type="tel" id="parent_phone" class="input" name="parent_phone" placeholder="" required>
                            <div class="cut"></div>
                            <label for="parent_phone" class="placeholder">Телефон</label>               
                        </div>
                    </div>

                    <div class="children">
                        <h3 class="title">Данные о ребенке</h3>
                        <div class="input-container ic1">
                            <input type="text" id="child_name" class="input" name="child_name" placeholder="" required>
                            <div class="cut"></div>
                            <label for="child_name" class="placeholder">ФИО ребенка</label>
                        </div>
                        <div class="input-container ic2">
                            <input type="date" id="child_birth_date" class="input" name="child_birth_date" placeholder="" required>
                            <div class="cut"></div>
                            <label for="child_birth_date" class="placeholder">Дата рождения</label>
                        </div>
                        <div class="input-container ic3">
                            <select class="select_shift" id="shift" name="shift" required>
                                <option value="first">1 смена</option>
                                <option value="second">2 смена</option>
                                <option value="third">3 смена</option>
                            </select>
                        </div>
                        <label>
                            <input type="checkbox" name="consent" required> Согласие на обработку персональных данных
                        </label>
                        <div class="button-container">
                            <button type="submit" class="submit">Забронировать билет</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
        <!-- форма для кода подвтерждения -->
        <div id="confirmation-code-section" style="display:none;">
            <h3>Введите код подтверждения</h3>
            <input type="text" id="confirmation_code_input" placeholder="Код подтверждения">
            <input type="hidden" id="booking_id" value=""> 
            <button id="verify_code_button">Проверить код</button>
            <div id="verification_response"></div>
        </div>
        <!-- инф о брони -->
        <div id="booking-details" style="display:none;">
            <h3>Информация о бронировании</h3>
            <p><strong>ФИО родителя:</strong> <span id="booking-parent-name"></span></p>
            <p><strong>Электронная почта:</strong> <span id="booking-parent-email"></span></p>
            <p><strong>Телефон:</strong> <span id="booking-parent-phone"></span></p>
            <p><strong>ФИО ребенка:</strong> <span id="booking-child-name"></span></p>
            <p><strong>Дата рождения ребенка:</strong> <span id="booking-child-birth-date"></span></p>
            <p><strong>Смена:</strong> <span id="booking-shift"></span></p>
        </div>

        <script>
    jQuery(document).ready(function($) {
        var formSubmitted = false; // Переменная для отслеживания отправки формы

        $('#booking-form').on('submit', function(e) {
            e.preventDefault();

            // Проверяем, была ли форма уже отправлена
            if (formSubmitted) {
                return; // Если да, выходим из функции
            }
            formSubmitted = true; // Устанавливаем флаг, что форма отправлена

            var formData = $(this).serialize();
            $.ajax({
                url: '<?php echo admin_url('admin-ajax.php'); ?>',
                type: 'POST',
                data: formData + '&action=send_confirmation_code',
                success: function(response) {
                    if (response.success) {
                        $('#confirmation-code-section').show();
                        $('#booking-form').hide();
                        $('#booking_id').val(response.data.id); // Сохраняем booking_id
                        $('#verification_response').html('<p>Код подтверждения отправлен на вашу почту.</p>');
                    } else {
                        $('#verification_response').html('<p>Ошибка: ' + response.data + '</p>');
                    }
                },
                complete: function() {
                    formSubmitted = false; // Сбрасываем флаг после завершения запроса
                }
            });
        });

        $('#verify_code_button').on('click', function() {
            var confirmation_code = $('#confirmation_code_input').val();
            var booking_id = $('#booking_id').val(); // Получаем booking_id из скрытого поля
            $.ajax({
                url: '<?php echo admin_url('admin-ajax.php'); ?>',
                type: 'POST',
                data: {
                    action: 'verify_confirmation_code',
                    confirmation_code: confirmation_code,
                    booking_id: booking_id
                },
                success: function(response) {
                    if (response.success) {
                        $('#verification_response').html('<p>Бронирование успешно завершено!</p>');
                        $('#confirmation-code-section').hide();
                        $('#booking-details').show();
                        // Заполнение информации о брони
                        $('#booking-parent-name').text(response.data.parent_name);
                        $('#booking-parent-email').text(response.data.parent_email);
                        $('#booking-parent-phone').text(response.data.parent_phone);
                        $('#booking-child-name').text(response.data.child_name);
                        $('#booking-child-birth-date').text(response.data.child_birth_date);
                        $('#booking-shift').text(response.data.shift);
                    } else {
                        $('#verification_response').html('<p>Ошибка: ' + response.data + '</p>');
                    }
                }
            });
        });
    });
</script>
        <?php
        return ob_get_clean();
    }

    public function send_confirmation_code() {
        global $wpdb;
    
        // Проверяем, что запрос отправлен методом POST
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            wp_send_json_error('Недопустимый метод запроса.');
            return;
        }
    
        $parent_name = sanitize_text_field($_POST['parent_name']);
        $parent_email = sanitize_email($_POST['parent_email']);
        $parent_phone = sanitize_text_field($_POST['parent_phone']);
        $child_name = sanitize_text_field($_POST['child_name']);
        $child_birth_date = sanitize_text_field($_POST['child_birth_date']);
        $shift = sanitize_text_field($_POST['shift']);
    
        if (empty($parent_name) || empty($parent_email) || empty($parent_phone) || empty($child_name) || empty($child_birth_date) || empty($shift)) {
            wp_send_json_error('Все поля обязательны для заполнения.');
            return;
        }
    
        // Проверяем, существует ли уже бронирование с такими же данными
        $existing_booking = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}wfm_bookings WHERE parent_email = %s AND child_name = %s AND child_birth_date = %s",
            $parent_email,
            $child_name,
            $child_birth_date
        ));
    
        if ($existing_booking) {
            wp_send_json_error('Бронирование с такими данными уже существует.');
            return;
        }
    
        $confirmation_code = rand(100000, 999999);
    
        $table_name = $wpdb->prefix . 'wfm_bookings';
        $data = array(
            'parent_name' => $parent_name,
            'parent_email' => $parent_email,
            'parent_phone' => $parent_phone,
            'child_name' => $child_name,
            'child_birth_date' => $child_birth_date,
            'shift' => $shift,
            'confirmation_code' => $confirmation_code,
        );
    
        $result = $wpdb->insert($table_name, $data);
    
       
        if ($result !== false) {
            $to = $parent_email;
            $subject = 'Код подтверждения для бронирования';
            $message = 'Ваш код подтверждения: ' . $confirmation_code;
            $headers = "From: DOL Akakul <workdiplom@bk.ru>\r\n";
            $headers .= "Content-Type: text/plain; charset=UTF-8\r\n";
    
            // Отправка email с использованием функции wp_mail()
            $mail_sent = wp_mail($to, $subject, $message, $headers);
    
            if ($mail_sent) {
                wp_send_json_success(array(
                    'confirmation_code' => $confirmation_code,
                    'id' => $wpdb->insert_id,
                ));
            } else {
                wp_send_json_error('Ошибка при отправке кода подтверждения на почту.');
            }
        } else {
            wp_send_json_error('Ошибка при сохранении данных в базу данных: ' . $wpdb->last_error);
        }
    }
        
    

    public function verify_confirmation_code() {
        global $wpdb;

        // Проверяем, что запрос отправлен методом POST
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            wp_send_json_error('Недопустимый метод запроса.');
            return;
        }

        $confirmation_code = sanitize_text_field($_POST['confirmation_code']);
        $booking_id = intval($_POST['booking_id']);

        $table_name = $wpdb->prefix . 'wfm_bookings';
        $booking = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table_name WHERE id = %d", $booking_id));

        if ($booking && $booking->confirmation_code == $confirmation_code) {
            // Код подтверждения верный, можно завершить бронирование
            wp_send_json_success(array(
                'parent_name' => $booking->parent_name,
                'parent_email' => $booking->parent_email,
                'parent_phone' => $booking->parent_phone,
                'child_name' => $booking->child_name,
                'child_birth_date' => $booking->child_birth_date,
                'shift' => $booking->shift,
            ));
        } else {
            wp_send_json_error('Неверный код подтверждения.');
        }
    }
}

new BookingSystem();