<?php
ob_start();
class BookingAdmin {
    public function __construct() {
        add_action('admin_menu', array($this, 'create_admin_menu'));
        add_action('admin_init', array($this, 'handle_booking_actions'));
        add_action('wp_ajax_create_user', array($this, 'handle_create_user')); // AJAX handler for user creation
        add_action('admin_enqueue_scripts', array($this, 'enqueue_scripts')); 
        add_action('wp_enqueue_scripts', array($this, 'booking_enqueue_scripts'));
    }

    function booking_enqueue_scripts() {
        wp_enqueue_style('booking-system-css', plugin_dir_url(__FILE__) . 'styles/booking-system.css');
    } 

    public function enqueue_scripts() {
        wp_enqueue_script('jquery-inputmask', 'https://cdnjs.cloudflare.com/ajax/libs/jquery.inputmask/5.0.6/jquery.inputmask.min.js', array('jquery'), null, true);
    }

    public function create_admin_menu() {
         // main page
    add_menu_page(
        'Управление бронированиями', //name page
        'Бронирования', // name menu
        'manage_options', // only for admin
        'booking-management', // slug
        array($this, 'display_bookings'), // func for view inf
        'dashicons-calendar-alt', // icon
        20 // position
    );

    // саб страница добавить бронирование
    add_submenu_page(
        'booking-management', // slug of parent page
        'Добавить бронирование', // name page
        'Добавить бронирование', // name menu
        'manage_options', // only for admin
        'booking-add', // slug
        'booking_admin_page' // func for view inf
    );
    }
    public function display_bookings() {
        global $wpdb;
        $table_name = $wpdb->prefix . 'wfm_bookings';
    
        // Обработка фильтров
        $parent_name_filter = '';
        $child_name_filter = '';
        $status_filter = '';
    
        if (isset($_GET['parent_name']) && !empty($_GET['parent_name'])) {
            $parent_name_filter = sanitize_text_field($_GET['parent_name']);
        }
        if (isset($_GET['child_name']) && !empty($_GET['child_name'])) {
            $child_name_filter = sanitize_text_field($_GET['child_name']);
        }

        if (isset($_GET['status']) && !empty($_GET['status'])) {
            $status_filter = sanitize_text_field($_GET['status']);
        }
    
        // sql запрос с условиями фильтрации
        $query = "SELECT * FROM $table_name WHERE 1=1"; // 1=1 для удобства добавления условий
        if (!empty($parent_name_filter)) {
            $query .= " AND parent_name LIKE '%$parent_name_filter%'";
        }
        if (!empty($child_name_filter)) {
            $query .= " AND child_name LIKE '%$child_name_filter%'";
        }

        if (!empty($status_filter)) {
            $query .= " AND status = '$status_filter'";
        }
    
        $bookings = $wpdb->get_results($query);
    
        echo '<h1>Управление бронированиями</h1>';
    
        // фильтрации
        echo '<form method="GET" action="">';
        echo '<input type="hidden" name="page" value="booking-management">';
        echo '<input type="text" name="parent_name" value="' . esc_attr($parent_name_filter) . '" placeholder="ФИО родителя...">';
        echo '<input type="text" name="child_name" value="' . esc_attr($child_name_filter) . '" placeholder="ФИО ребенка...">';
        echo '<select name="status">';
        echo '<option value="">Все статусы</option>';
        echo '<option value="processing"' . selected($status_filter, 'processing', false) . '>Обработка</option>';
        echo '<option value="payment pending"' . selected($status_filter, 'payment pending', false) . '>Ожидается оплата</option>';
        echo '<option value="completed"' . selected($status_filter, 'completed', false) . '>Выполнен</option>';
        echo '<option value="on hold"' . selected($status_filter, 'on hold', false) . '>На удержании</option>';
        echo '<option value="cancelled"' . selected($status_filter, 'cancelled', false) . '>Отменен</option>';
        echo '<option value="booked"' . selected($status_filter, 'booked', false) . '>Забронирован</option>';
        echo '</select>';
        echo '<button type="submit">Найти</button>';
        echo '<a href="' . admin_url('admin.php?page=booking-management') . '" class="button">Сбросить фильтры</a>'; // Кнопка для сброса фильтров
        echo '</form>';
    
        echo '<table>';
        echo '<tr><th>ID</th><th>ФИО родителя</th><th>ФИО ребенка</th><th>Статус</th><th>Действия</th></tr>';
    
        foreach ($bookings as $booking) {
            echo '<tr>';
           
            echo '<td>' . esc_html($booking->id) . '</td>';
            echo '<td>' . esc_html($booking->parent_name) . '</td>';
            echo '<td>' . esc_html($booking->child_name) . '</td>';
            echo '<td>' . esc_html($booking->status) . '</td>';
            echo '<td>';
            echo '<form method="POST" action="">';
            echo '<input type="hidden" name="booking_id" value="' . esc_attr($booking->id) . '">';
            echo '<select name="booking_status">';
            echo '<option value="processing"' . selected($booking->status, 'processing', false) . '>Обработка</option>';
            echo '<option value="payment pending"' . selected($booking->status, 'payment pending', false) . '>Ожидается оплата</option>';
            echo '<option value="completed"' . selected($booking->status, 'completed', false) . '>Выполнен</option>';
            echo '<option value="on hold"' . selected($booking->status, 'on hold', false) . '>На удержании</option>';
            echo '<option value="cancelled"' . selected($booking->status, 'cancelled', false) . '>Отменен</option>';
            echo '<option value="booked"' . selected($booking->status, 'booked', false) . '>Забронирован</option>';
            echo '</select>';
            echo '<button type="submit" name="update_booking">Обновить</button>';
            echo '</form>';
            echo '</td>';
            echo '</tr>';
        }
        echo '</table>';
    }
    public function handle_booking_actions() {
        global $wpdb;
        $table_name = $wpdb->prefix . 'wfm_bookings';
    
        // Обработка обновления бронирования
        if (isset($_POST['update_booking'])) {
            $booking_id = intval($_POST['booking_id']);
            $new_status = sanitize_text_field($_POST['booking_status']);
    
            // Обновление статуса бронирования
            $wpdb->update(
                $table_name,
                array('status' => $new_status),
                array('id' => $booking_id)
            );
    
            // Редирект на страницу управления бронированиями
            wp_redirect(admin_url('admin.php?page=booking-management'));
            exit;
        }
    
        // Обработка удаления бронирования
        if (isset($_GET['action']) && $_GET['action'] == 'delete' && isset($_GET['id'])) {
            $booking_id = intval($_GET['id']);
            $wpdb->delete($table_name, array('id' => $booking_id));
    
            // Редирект на страницу управления бронированиями с сообщением об успехе
            wp_redirect(admin_url('admin.php?page=booking-management&message=deleted'));
            exit;
        }
    
        // Удалите этот вывод из функции, чтобы избежать проблемы с заголовками
        // if (isset($_GET['message']) && $_GET['message'] == 'deleted') {
        //     echo "<div class='updated'><p>Бронирование успешно удалено!</p></div>";
        // }
    }
    
}

new BookingAdmin();

// CRUD for admin
function booking_admin_page() {
    ob_start();
    ?>
    <div class="wrap">
        <h1>Управление Бронированиями</h1>
        
        <h2>Добавить новое бронирование</h2>
        <form method="POST" action="" class="booking-form">
            <input type="hidden" name="action" value="create_booking">
            <h4>Данные родителя</h4>
            <label for="parent_name">ФИО родителя</label>
            <input type="text" id="parent_name" name="parent_name" required>

            <label for="parent_email">Электронная почта</label>
            <input type="email" id="parent_email" name="parent_email" required>

            <label for="parent_phone">Телефон</label>
            <input type="tel" id="parent_phone" name="parent_phone" required> 

            <h4>Данные о ребенке</h4>
            <label for="child_name">ФИО ребенка</label>
            <input type="text" id="child_name" name="child_name" required>

            <label for="child_birth_date">Дата рождения</label>
            <input type="date" id="child_birth_date" name="child_birth_date" required>

            <label for="shift">Выбор смены</label>
            <select id="shift" name="shift" required>
                <option value="first">1 смена</option>
                <option value="second">2 смена</option>
                <option value="third">3 смена</option>
            </select>

            <button type="submit">Добавить бронирование</button>
        </form>
        <h2>Список бронирований</h2>

<!-- Форма фильтрации -->
<form method="GET" action="">
            <input type="hidden" name="page" value="booking-add">
            <input type="text" name="parent_name" value="<?php echo isset($_GET['parent_name']) ? esc_attr($_GET['parent_name']) : ''; ?>" placeholder="ФИО родителя...">
            <input type="text" name="child_name" value="<?php echo isset($_GET['child_name']) ? esc_attr($_GET['child_name']) : ''; ?>" placeholder="ФИО ребенка...">
            <input type="tel"  name="parent_phone" value="<?php echo isset($_GET['parent_phone']) ? esc_attr($_GET['parent_phone']) : ''; ?>" placeholder="Телефон...">
            <input type="date" name="child_birth_date" value="<?php echo isset($_GET['child_birth_date']) ? esc_attr($_GET['child_birth_date']) : ''; ?>" placeholder="Дата рождения...">
            <button type="submit">Фильтровать</button>
            <a href="<?php echo admin_url('admin.php?page=booking-add'); ?>" class="button">Сбросить фильтры</a> <!-- Кнопка для сброса фильтров -->
        </form>
        <table class="widefat fixed">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Имя родителя</th>
                    <th>Email</th>
                    <th>Телефон</th>
                    <th>Имя ребенка</th>
                    <th>Дата рождения</th>
                    <th>Смена</th>
                    <th>Статус</th>
                    <th>Действия</th>
                </tr>
            </thead>
            <tbody>
                <?php
                global $wpdb;
                $table_name = $wpdb->prefix . 'wfm_bookings';
 // Обработка фильтров
 $parent_name_filter = isset($_GET['parent_name']) ? sanitize_text_field($_GET['parent_name']) : '';
 $child_name_filter = isset($_GET['child_name']) ? sanitize_text_field($_GET['child_name']) : '';
 $parent_phone_filter = isset($_GET['parent_phone']) ? sanitize_text_field($_GET['parent_phone']) : '';
 $child_birth_date_filter = isset($_GET['child_birth_date']) ? sanitize_text_field($_GET['child_birth_date']) : '';

 // SQL-запрос с учетом фильтров
 $query = "SELECT * FROM $table_name WHERE 1=1"; // начнем с базового запроса

 if (!empty($parent_name_filter)) {
     $query .= $wpdb->prepare(" AND parent_name LIKE %s", '%' . $wpdb->esc_like($parent_name_filter) . '%');
 }
 if (!empty($child_name_filter)) {
     $query .= $wpdb->prepare(" AND child_name LIKE %s", '%' . $wpdb->esc_like($child_name_filter) . '%');
 }
 if (!empty($parent_phone_filter)) {
     $query .= $wpdb->prepare(" AND parent_phone LIKE %s", '%' . $wpdb->esc_like($parent_phone_filter) . '%');
 }
 if (!empty($child_birth_date_filter)) {
     $query .= $wpdb->prepare(" AND child_birth_date = %s", $child_birth_date_filter);
 }
 $bookings = $wpdb->get_results($query);

                foreach ($bookings as $booking) {
                    echo "<tr>
                        <td>{$booking->id}</td>
                        <td>{$booking->parent_name}</td>
                        <td>{$booking->parent_email}</td>
                        <td>{$booking->parent_phone}</td>
                        <td>{$booking->child_name}</td>
                        <td>{$booking->child_birth_date}</td>
                        <td>{$booking->shift}</td>
                        <td>{$booking->status}</td>
                        <td>
                    <button class='edit-button' data-id='{$booking->id}' data-parent_name='{$booking->parent_name}' data-parent_email='{$booking->parent_email}' data-parent_phone='{$booking->parent_phone}' data-child_name='{$booking->child_name}' data-child_birth_date='{$booking->child_birth_date}' data-shift='{$booking->shift}'>Редактировать</button>
                    <a href='" . admin_url("admin.php?page=booking-management&action=delete&id={$booking->id}") . "' onclick='return confirm(\"Вы уверены, что хотите удалить это бронирование?\")'>Удалить</a>
                    </td>
                    </tr>";
                }
                ?>
            </tbody>
        </table>
            </div>

    <!-- Модальное окно редактирования -->
    <div id="editModal" style="display:none;">
        <div class="modal-content">
            <span class="close">&times;</span>
            <h2>Редактировать бронирование</h2>
            <form method="POST" id="editForm">
                <input type="hidden" name="action" value="update_booking">
                <input type="hidden" name="booking_id" id="booking_id">

                <label for="edit_parent_name">ФИО родителя</label>
                <input type="text" id="edit_parent_name" name="parent_name" required>

                <label for="edit_parent_email">Электронная почта</label>
                <input type="email" id="edit_parent_email" name="parent_email" required>

                <label for="edit_parent_phone">Телефон</label>
                <input type="tel" id="edit_parent_phone" name="parent_phone" required>

                <label for="edit_child_name">ФИО ребенка</label>
                <input type="text" id="edit_child_name" name="child_name" required>

                <label for="edit_child_birth_date">Дата рождения ребенка</label>
                <input type="date" id="edit_child_birth_date" name="child_birth_date" required>

                <label for="edit_shift">Смена</label>
                <select id="edit_shift" name="shift" required>
                    <option value="first">1 смена</option>
                    <option value="second">2 смена</option>
                    <option value="third">3 смена</option>
                </select>

                <button type="submit">Обновить бронирование</button>
            </form>
        </div>
    </div>

    <script>
        // Открытие модального окна
        document.querySelectorAll('.edit-button').forEach(button => {
            button.addEventListener('click', function() {
                const id = this.getAttribute('data-id');
                const parentName = this.getAttribute('data-parent_name');
                const parentEmail = this.getAttribute('data-parent_email');
                const parentPhone = this.getAttribute('data-parent_phone');
                const childName = this.getAttribute('data-child_name');
                const childBirthDate = this.getAttribute('data-child_birth_date');
                const shift = this.getAttribute('data-shift');

                // Заполнение формы данными
                document.getElementById('booking_id').value = id;
                document.getElementById('edit_parent_name').value = parentName;
                document.getElementById('edit_parent_email').value = parentEmail;
                document.getElementById('edit_parent_phone').value = parentPhone;
                document.getElementById('edit_child_name').value = childName;
                document.getElementById('edit_child_birth_date').value = childBirthDate;
                document.getElementById('edit_shift').value = shift;

                // Показать модальное окно
                document.getElementById('editModal').style.display = 'block';
            });
        });

        // Закрытие модального окна
        document.querySelector('.close').addEventListener('click', function() {
            document.getElementById('editModal').style.display = 'none';
        });

        // Закрытие модального окна при клике вне его
        window.onclick = function(event) {
            if (event.target == document.getElementById('editModal')) {
                document.getElementById('editModal').style.display = 'none';
            }
        };

        // Маска для телефона
        jQuery(document).ready(function($) {
            $('#parent_phone_filter').inputmask({"mask": "+7 (999) 999-99-99"});
        });
        jQuery(document).ready(function($) {
            $('#parent_phone').inputmask({"mask": "+7 (999) 999-99-99"});
        });
        jQuery(document).ready(function($) {
            $('#edit_parent_phone').inputmask({"mask": "+7 (999) 999-99-99"});
        });
    </script>

    <style>
        /* CSS для модального окна */
        .modal-content {
            background-color: #fefefe;
            margin: 15% auto;
            padding: 20px;
            border: 1px solid #888;
            width: 80%;
            max-width: 500px;
        }

        #editModal {
            display: none; /* Скрыто по умолчанию */
            position: fixed; /* Остается на месте */
            z-index: 1; /* Сверху */
            left: 0;
            top: 0;
            width: 100%; /* Полная ширина */
            height: 100%; /* Полная высота */
            overflow: auto; /* Включить прокрутку, если необходимо */
            background-color: rgb(0,0,0); /* Цвет фона */
            background-color: rgba(0,0,0,0.4); /* Полупрозрачный фон */
        }

        .close {
            color: #aaa;
            float: right;
            font-size: 28px;
            font-weight: bold;
        }

        .close:hover,
        .close:focus {
            color: black;
            text-decoration: none;
            cursor: pointer;
        }
    </style>

    <?php

    // Обработка создания нового бронирования
    if (isset($_POST['action']) && $_POST['action'] == 'create_booking') {
        $parent_name = sanitize_text_field($_POST['parent_name']);
        $parent_email = sanitize_email($_POST['parent_email']);
        $parent_phone = sanitize_text_field($_POST['parent_phone']);
        $child_name = sanitize_text_field($_POST['child_name']);
        $child_birth_date = sanitize_text_field($_POST['child_birth_date']);
        $shift = sanitize_text_field($_POST['shift']);
        
        // Вставка нового бронирования в базу данных
        $wpdb->insert($table_name, [
            'parent_name' => $parent_name,
            'parent_email' => $parent_email,
            'parent_phone' => $parent_phone,
            'child_name' => $child_name,
            'child_birth_date' => $child_birth_date,
            'shift' => $shift,
            'status' => 'active'
        ]);
        
        echo "<div class='updated'><p>Бронирование успешно добавлено!</p></div>";
    }

    // Обработка обновления существующего бронирования
    if (isset($_POST['action']) && $_POST['action'] == 'update_booking') {
        $booking_id = intval($_POST['booking_id']);
        $parent_name = sanitize_text_field($_POST['parent_name']);
        $parent_email = sanitize_email($_POST['parent_email']);
        $parent_phone = sanitize_text_field($_POST['parent_phone']);
        $child_name = sanitize_text_field($_POST['child_name']);
        $child_birth_date = sanitize_text_field($_POST['child_birth_date']);
        $shift = sanitize_text_field($_POST['shift']);

        // Обновление записи в базе данных
        $wpdb->update($table_name, [
            'parent_name' => $parent_name,
            'parent_email' => $parent_email,
            'parent_phone' => $parent_phone,
            'child_name' => $child_name,
            'child_birth_date' => $child_birth_date,
            'shift' => $shift
        ], ['id' => $booking_id]);

        echo "<div class='updated'><p>Бронирование успешно обновлено!</p></div>";
    }    
    ob_end_flush();
}
ob_end_flush();
