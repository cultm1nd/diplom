<?php

if (!defined('ABSPATH')) {
    exit;
}

class WooCommerce_Booking_Manual {

    public function __construct() {
        add_action('admin_menu', array($this, 'add_admin_booking_page'));
    }

    public function add_admin_booking_page() {
        add_submenu_page(
            'woocommerce-bookings', // Родительский slug (страница бронирований)
            __('Забронировать товар', 'woocommerce-booking'), // Заголовок страницы
            __('Забронировать товар', 'woocommerce-booking'), // Название в меню
            'manage_options', // Права доступа
            'admin-booking', // Slug страницы
            array($this, 'render_admin_booking_page') // Функция для отображения страницы
        );
    }

    public function render_admin_booking_page() {
        // Проверяем права доступа
        if (!current_user_can('manage_options')) {
            wp_die(__('У вас недостаточно прав для доступа к этой странице.', 'woocommerce-booking'));
        }

        // Обработка отправки формы
        if (isset($_POST['submit_admin_booking'])) {
            $result = $this->handle_admin_booking_request();
            if ($result) {
                echo '<div class="notice notice-success"><p>' . __('Бронирование успешно создано!', 'woocommerce-booking') . '</p></div>';
            } else {
                echo '<div class="notice notice-error"><p>' . __('Ошибка при создании бронирования.', 'woocommerce-booking') . '</p></div>';
            }
        }

        // Получаем все товары WooCommerce
        $products = wc_get_products(array(
            'status' => 'publish',
            'limit' => -1, // Получить все товары
        ));

        // Отображаем форму бронирования
        echo '<div class="wrap">';
        echo '<h1>' . __('Забронировать товар', 'woocommerce-booking') . '</h1>';
        echo '<form method="post" action="">';

        // Поля для данных покупателя
        echo '<table class="form-table" role="presentation">';
        echo '<tbody>';
        echo '<tr>';
        echo '<th scope="row"><label for="product_id">' . __('Выберите товар:', 'woocommerce-booking') . '</label></th>';
        echo '<td><select id="product_id" name="product_id" required>';
        foreach ($products as $product) {
            echo '<option value="' . esc_attr($product->get_id()) . '">' . esc_html($product->get_name()) . '</option>';
        }
        echo '</select>';
        echo '</td>';
        echo '</tr>';

        echo '<tr>';
        echo '<th><label for="parent_name">' . __('Ф.И.О. родителя:', 'woocommerce-booking') . '</label></th>';
        echo '<td><input type="text" id="parent_name" name="parent_name" required></td>';
        echo '</tr>';

        echo '<tr>';
        echo '<th><label for="child_name">' . __('Ф.И.О. ребенка:', 'woocommerce-booking') . '</label></th>';
        echo '<td><input type="text" id="child_name" name="child_name" required></td>';
        echo '</tr>';

        echo '<tr>';
        echo '<th><label for="child_bdate">' . __('Дата рождения ребенка:', 'woocommerce-booking') . '</label></th>';
        echo '<td><input type="date" id="child_bdate" name="child_bdate" required></td>';
        echo '</tr>';

        echo '<tr>';
        echo '<th><label for="email">' . __('Email:', 'woocommerce-booking') . '</label></th>';
        echo '<td><input type="email" id="email" name="email" required></td>';
        echo '</tr>';

        echo '<tr>';
        echo '<th><label for="phone">' . __('Телефон:', 'woocommerce-booking') . '</label></th>';
        echo '<td><input type="tel" id="phone" name="phone" required></td>';
        echo '</tr>';

        echo '</tbody>';
        echo '</table>';

        // Кнопка отправки формы
        echo '<p class="submit">
                <input type="submit" name="submit_admin_booking" class="button button-primary" value="' . __('Забронировать', 'woocommerce-booking') . '">
              </p>';

        echo '</form>';
        echo '</div>';
    }

    private function handle_admin_booking_request() {
        global $wpdb;
        $table_name = $wpdb->prefix . 'woocommerce_bookings';

        // Проверяем, заполнены ли все поля
        if (empty($_POST['product_id']) || empty($_POST['parent_name']) || empty($_POST['child_name']) || empty($_POST['child_bdate']) || empty($_POST['email']) || empty($_POST['phone'])) {
            return false;
        }

        $current_product = wc_get_product(intval($_POST['product_id']));

        // Собираем данные из формы
        $product_id = intval($_POST['product_id']);
        $product_name = sanitize_text_field($current_product->get_name());
        $parent_name = sanitize_text_field($_POST['parent_name']);
        $child_name = sanitize_text_field($_POST['child_name']);
        $child_bdate = sanitize_text_field($_POST['child_bdate']);
        $email = sanitize_email($_POST['email']);
        $phone = sanitize_text_field($_POST['phone']);

        // Генерация токена подтверждения
        $confirmation_token = $this->generate_booking_token();

        // Сохраняем бронирование в базу данных
        $result = $wpdb->insert(
            $table_name,
            array(
                'product_id' => $product_id,
                'product_name' => $product_name,
                'parent_name' => $parent_name,
                'child_name' => $child_name,
                'child_bdate' => $child_bdate,
                'email' => $email,
                'phone' => $phone,
                'confirmation_token' => $confirmation_token,
                'is_confirmed' => 1, // Автоматически подтверждаем бронирование, созданное администратором
            )
        );

        return $result !== false;
    }

    private function generate_booking_token() {
        return bin2hex(random_bytes(16)); // Генерация случайного токена
    }
}

// Инициализация класса
new WooCommerce_Booking_Manual();